import { Link } from 'react-router-dom'
import logo from '../assets/bamali-logo.png'

export default function Footer() {
  return (
    <footer className="bg-ink px-0 pb-4 pt-10 text-white">
      <div className="mx-auto grid w-[94%] max-w-[1200px] grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1.4fr_1fr] lg:gap-9">
        <div>
          <img src={logo} alt="Bamali Trendz" className="h-[65px] w-[115px] object-contain" />
          <p className="mt-2 max-w-xs text-[10px] leading-6 text-[#aaa]">
            Personalized stainless-steel gifts, custom name &amp; photo engraving, made with love in India.
          </p>
          {/* Facebook Link with Icon */}
          <div className="mt-3">
            <a
              href="https://www.facebook.com/profile.php?id=61593371213242"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="inline-flex items-center text-[10px] text-[#aaa] hover:text-white transition-colors"
            >
              <svg className="mr-1.5 h-4 w-4 fill-current text-[#d9ae63]" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              Follow on Facebook
            </a>
          </div>
        </div>
        <div>
          <h4 className="mb-3 text-[11px] font-bold text-[#d9ae63]">Quick Links</h4>
          <Link className="mb-2 block text-[10px] text-[#aaa] hover:text-white" to="/">Home</Link>
          <Link className="mb-2 block text-[10px] text-[#aaa] hover:text-white" to="/contact">Contact Us</Link>
          <a
            className="mb-2 block text-[10px] text-[#aaa] hover:text-white"
            href="https://www.facebook.com/profile.php?id=61593371213242"
            target="_blank"
            rel="noopener noreferrer"
          >
            Facebook Page
          </a>
          <Link className="mb-2 block text-[10px] text-[#aaa] hover:text-white" to="/terms">Terms &amp; Conditions</Link>
          <Link className="mb-2 block text-[10px] text-[#aaa] hover:text-white" to="/privacy">Privacy Policy</Link>
        </div>
        <div>
          <h4 className="mb-3 text-[11px] font-bold text-[#d9ae63]">Contact</h4>
          <a className="mb-2 block text-[10px] text-[#aaa] hover:text-white" href="tel:+916367077048">+91 6367077048</a>
          <a className="mb-2 block text-[10px] text-[#aaa] hover:text-white" href="mailto:support@bamalitrendz.com">support@bamalitrendz.com</a>
          <p className="text-[10px] leading-5 text-[#aaa]">47, Vishwa Nagar, New Sanganer,<br />Jaipur, Rajasthan – 302019</p>
        </div>
        <div>
          <h4 className="mb-3 text-[11px] font-bold text-[#d9ae63]">Store Hours</h4>
          <p className="text-[10px] leading-5 text-[#aaa]">9:00 AM – 10:00 PM<br />(Daily)</p>
        </div>
      </div>
      <div className="mx-auto mt-7 w-[94%] max-w-[1200px] border-t border-[#34302c] pt-3 text-center text-[9px] text-[#777]">© 2026 Bamali Trendz. All rights reserved. Made with ♥ in India.</div>
    </footer>
  )
}