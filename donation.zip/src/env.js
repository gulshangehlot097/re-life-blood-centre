const env = {
  AMAZON_STORE_URL:
    "https://www.amazon.in/stores/Home/page/0B47BCB9-BB07-4323-B665-FDE20C43B730?lp_asin=B0DP4Q4GTL&ref_=ast_bln&store_ref=bl_ast_dp_brandlogo_sto",
};

export default env;
